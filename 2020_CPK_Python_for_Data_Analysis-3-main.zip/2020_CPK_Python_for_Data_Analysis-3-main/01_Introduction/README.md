## Дополнительный материалы
* [Гид по git](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/master/01_Introduction/2020_CPK_1_0_git.ipynb)
* [Стиль PEP8](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/master/01_Introduction/2020_CPK_1_0_Coding_Style.ipynb) 
* [Основы работы с Jupyter Notebook. Markdown](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/master/01_Introduction/2020_CPK_1_0_Jupyter.ipynb)

## 1 занятие (теория)
* [Целые и вещественные числа, логические переменные](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/master/01_Introduction/2020_CPK_1_1_Int_Float_Bool.ipynb)
