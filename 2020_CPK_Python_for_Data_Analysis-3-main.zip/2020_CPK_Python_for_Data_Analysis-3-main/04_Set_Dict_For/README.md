## 4 занятие (теория)
* [Множества и словари](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/master/04_Set_Dict_For/2020_CPK_4_1_Set_Dict.ipynb)
* [Цикл for](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/master/04_Set_Dict_For/2020_CPK_4_2_For.ipynb)

## Задачи
* [Задачи](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/master/04_Set_Dict_For/2020_%D0%A1PK_4_0_Problems.ipynb)
* [Решения](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/main/04_Set_Dict_For/2020_%D0%A1PK_4_0_Problems_Solution.ipynb)
