## 3 занятие (теория)
* [Срезы строк и списков](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/master/03_If_Else_While/2020_CPK_3_1_Slices.ipynb)
* [Условный оператор. Цикл While](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/master/03_If_Else_While/2020_CPK_3_2_If_Else.ipynb)

## Задачи
* [Задачи](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/master/03_If_Else_While/2020_CPK_3_0_Problems.ipynb)
* [Решения](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/master/03_If_Else_While/2020_CPK_3_0_Problems_Solution.ipynb)
