## 2 занятие (теория)
* [Строки. Ввод и форматирование. Функция print()](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/master/02_Strings_Lists_Tuples/2020_CPK_2_1_Strings_Input.ipynb)
* [Списки и кортежи](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/master/02_Strings_Lists_Tuples/2020_CPK_2_2_List_Tuple.ipynb)

## Задачи
* [Задачи](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/master/02_Strings_Lists_Tuples/2020_CPK_2_0_Problems.ipynb)
* [Решения](https://github.com/rogovich/2020_CPK_Python_for_Data_Analysis-3/blob/master/02_Strings_Lists_Tuples/2020_CPK_2_0_Problems_Solution.ipynb)

